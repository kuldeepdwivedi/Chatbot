package com.example.medichat.medichat;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final EditText etname=(EditText) findViewById(R.id.etname);
        final EditText etpassword=(EditText) findViewById(R.id.etpassword);
        final Button blogin =(Button) findViewById(R.id.blogin);
        final Button bsignup =(Button) findViewById(R.id.bsignup);
        final TextView tvforgotpassword=(TextView) findViewById(R.id.tvforgotpassword);
        final TextView or=(TextView) findViewById(R.id.or);


    }

}
